using System;
using System.Collections.Generic;
using Bindito.Core;
using HarmonyLib;
using Timberborn.ModManagerScene;
using Timberborn.Modding;
using Timberborn.Navigation;
using Timberborn.SingletonSystem;
using Timberborn.TerrainSystem;
using Timberborn.WaterSystem;
using UnityEngine;

namespace Calloatti.BeaversForReal
{
  // ==========================================
  // 1. HARMONY & DEPENDENCY INJECTION
  // ==========================================
  public class BeaversForRealStarter : IModStarter
  {
    public void StartMod(IModEnvironment modEnvironment)
    {
      new Harmony("calloatti.beaversforreal").PatchAll();
    }
  }

  [Context("Game")]
  public class BeaversForRealConfigurator : Configurator
  {
    protected override void Configure()
    {
      Bind<ShorelineManager>().AsSingleton();
    }
  }

  // ==========================================
  // 2. HARMONY PATCHES (PROTECT CUSTOM GROUP)
  // ==========================================
  [HarmonyPatch]
  public static class BeaversForRealPatches
  {
    // Prevent the vanilla game from crashing when dynamiting near our custom paths
    [HarmonyPatch(typeof(NavMeshSource), nameof(NavMeshSource.BlockEdge))]
    [HarmonyPrefix]
    public static bool BlockEdge_Prefix(int startNodeId, int endNodeId, int groupId)
    {
      return groupId != ShorelineManager.ShorelineGroupId;
    }

    [HarmonyPatch(typeof(NavMeshSource), nameof(NavMeshSource.UnblockEdge))]
    [HarmonyPrefix]
    public static bool UnblockEdge_Prefix(int startNodeId, int endNodeId, int groupId)
    {
      return groupId != ShorelineManager.ShorelineGroupId;
    }
  }

  // ==========================================
  // 3. CACHED EDGE DATA STRUCTURE
  // ==========================================
  public class ShorelineEdge
  {
    public Vector3Int Upper;
    public Vector3Int Lower;
    public bool IsActive;
    public NavMeshEdge EdgeDown;
    public NavMeshEdge EdgeUp;

    public ShorelineEdge(Vector3Int upper, Vector3Int lower)
    {
      Upper = upper;
      Lower = lower;
    }
  }

  // ==========================================
  // 4. CORE LOGIC MANAGER
  // ==========================================
  public class ShorelineManager : ILoadableSingleton, IUpdatableSingleton, IDisposable
  {
    // Expose the ID statically so the Harmony patches can access it
    public static int ShorelineGroupId { get; private set; } = -1;

    private readonly ITerrainService _terrainService;
    private readonly INavMeshService _navMeshService;
    private readonly NavMeshGroupService _navMeshGroupService;
    private readonly IThreadSafeWaterMap _waterMap;

    private readonly List<ShorelineEdge> _shorelines = new List<ShorelineEdge>();
    private float _timer = 0f;

    // Debounce variables for extreme explosions
    private bool _needsRescan = false;
    private float _rescanCooldown = 0f;
    private const float DebounceTime = 1.5f;

    public ShorelineManager(
      ITerrainService terrainService,
      INavMeshService navMeshService,
      NavMeshGroupService navMeshGroupService,
      IThreadSafeWaterMap waterMap)
    {
      _terrainService = terrainService;
      _navMeshService = navMeshService;
      _navMeshGroupService = navMeshGroupService;
      _waterMap = waterMap;
    }

    public void Load()
    {
      ShorelineGroupId = _navMeshGroupService.GetOrAddGroupId("Calloatti.BeaversForReal");

      RescanMap();
      _terrainService.TerrainHeightChanged += OnTerrainChanged;
    }

    public void Dispose()
    {
      if (_terrainService != null)
      {
        _terrainService.TerrainHeightChanged -= OnTerrainChanged;
      }
    }

    private void OnTerrainChanged(object sender, TerrainHeightChangeEventArgs e)
    {
      if (!_needsRescan)
      {
        // Pre-emptively drop custom edges on the first explosion before vanilla tries to update
        ClearActiveEdges();
      }
      _needsRescan = true;
      _rescanCooldown = DebounceTime;
    }

    private void ClearActiveEdges()
    {
      foreach (var edge in _shorelines)
      {
        if (edge.IsActive)
        {
          try { _navMeshService.RemoveEdge(edge.EdgeDown); } catch { }
          try { _navMeshService.RemoveEdge(edge.EdgeUp); } catch { }
          edge.IsActive = false;
        }
      }
    }

    private void RescanMap()
    {
      ClearActiveEdges();
      _shorelines.Clear();

      Vector3Int size = _terrainService.Size;

      Vector3Int[] orthogonalDeltas = new Vector3Int[] {
        new Vector3Int(1, 0, 0),
        new Vector3Int(-1, 0, 0),
        new Vector3Int(0, 1, 0),
        new Vector3Int(0, -1, 0)
      };

      for (int x = 0; x < size.x; x++)
      {
        for (int y = 0; y < size.y; y++)
        {
          Vector2Int cell = new Vector2Int(x, y);

          foreach (Vector3Int current in _terrainService.GetAllHeightsInCell(cell))
          {
            foreach (var delta in orthogonalDeltas)
            {
              Vector3Int neighborCell3D = new Vector3Int(current.x + delta.x, current.y + delta.y, current.z);

              if (!_terrainService.Contains(neighborCell3D)) continue;

              int neighborZ = _terrainService.GetTerrainHeightBelow(neighborCell3D);

              if (neighborZ >= 0 && neighborZ < current.z)
              {
                Vector3Int lowerNeighbor = new Vector3Int(neighborCell3D.x, neighborCell3D.y, neighborZ);
                _shorelines.Add(new ShorelineEdge(current, lowerNeighbor));
              }
            }
          }
        }
      }
    }

    public void UpdateSingleton()
    {
      if (_needsRescan)
      {
        _rescanCooldown -= Time.deltaTime;
        if (_rescanCooldown <= 0f)
        {
          _needsRescan = false;
          RescanMap();
          UpdateEdges();
        }
        return;
      }

      _timer += Time.deltaTime;
      if (_timer < 0.5f) return;
      _timer = 0f;

      UpdateEdges();
    }

    private void UpdateEdges()
    {
      foreach (var shoreline in _shorelines)
      {
        float depth = _waterMap.WaterDepth(shoreline.Lower);
        float waterSurfaceZ = shoreline.Lower.z + depth;
        float delta = shoreline.Upper.z - waterSurfaceZ;

        bool shouldBeActive = delta <= 0.50f && depth > 0.1f;

        if (shouldBeActive && !shoreline.IsActive)
        {
          shoreline.IsActive = true;

          shoreline.EdgeDown = NavMeshEdge.CreateGrouped(shoreline.Upper, shoreline.Lower, ShorelineGroupId, false, 1.5f);
          shoreline.EdgeUp = NavMeshEdge.CreateGrouped(shoreline.Lower, shoreline.Upper, ShorelineGroupId, false, 1.5f);

          _navMeshService.AddEdge(shoreline.EdgeDown);
          _navMeshService.AddEdge(shoreline.EdgeUp);
        }
        else if (!shouldBeActive && shoreline.IsActive)
        {
          shoreline.IsActive = false;
          try { _navMeshService.RemoveEdge(shoreline.EdgeDown); } catch { }
          try { _navMeshService.RemoveEdge(shoreline.EdgeUp); } catch { }
        }
      }
    }
  }
}